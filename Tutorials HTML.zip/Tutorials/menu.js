function openMenu(){
	document.getElementById("MainMenu").style.width = "75%";
	//document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
	return 0;
}

function closeMenu(){
	document.getElementById("MainMenu").style.width = "0%";
	document.body.style.backgroundColor = "rgba(255,255,255,255)";
	return 0;
}
